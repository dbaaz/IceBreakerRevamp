package com.arbiter.droid.icebreakerprot1;


import android.app.Fragment;
import android.os.Bundle;

import android.support.v7.widget.LinearLayoutManager;

import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.ArrayList;


import android.widget.Toast;
import android.os.Handler;


import android.view.ViewGroup;
import android.view.MenuInflater;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link UsersViewFragment#newInstance} factory method to
 * create an instance of this fragment.
 */


public class UsersViewFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;


    private RecyclerView recyclerView;

    // @BindView(R.id.recycler_view)
    // RecyclerView recyclerView;


    private UsersViewAdapter mAdapter;

    private ArrayList<UserModel> modelList = new ArrayList<>();


    public UsersViewFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment UsersViewFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static UsersViewFragment newInstance(String param1, String param2) {
        UsersViewFragment fragment = new UsersViewFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    public static UsersViewFragment newInstance() {
        UsersViewFragment fragment = new UsersViewFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_users_view, container, false);

        // ButterKnife.bind(this);
        findViews(view);

        return view;

    }


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        setAdapter();


    }


    private void findViews(View view) {

        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
    }


    private void setAdapter() {


        modelList.add(new UserModel("Android", "Hello " + " Android"));
        modelList.add(new UserModel("Beta", "Hello " + " Beta"));
        modelList.add(new UserModel("Cupcake", "Hello " + " Cupcake"));
        modelList.add(new UserModel("Donut", "Hello " + " Donut"));
        modelList.add(new UserModel("Eclair", "Hello " + " Eclair"));
        modelList.add(new UserModel("Froyo", "Hello " + " Froyo"));
        modelList.add(new UserModel("Gingerbread", "Hello " + " Gingerbread"));
        modelList.add(new UserModel("Honeycomb", "Hello " + " Honeycomb"));
        modelList.add(new UserModel("Ice Cream Sandwich", "Hello " + " Ice Cream Sandwich"));
        modelList.add(new UserModel("Jelly Bean", "Hello " + " Jelly Bean"));
        modelList.add(new UserModel("KitKat", "Hello " + " KitKat"));
        modelList.add(new UserModel("Lollipop", "Hello " + " Lollipop"));
        modelList.add(new UserModel("Marshmallow", "Hello " + " Marshmallow"));
        modelList.add(new UserModel("Nougat", "Hello " + " Nougat"));
        modelList.add(new UserModel("Android O", "Hello " + " Android O"));


        mAdapter = new UsersViewAdapter(getActivity(), modelList);

        recyclerView.setHasFixedSize(true);

        // use a linear layout manager
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);


        recyclerView.setAdapter(mAdapter);


        mAdapter.SetOnItemClickListener(new UsersViewAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position, UserModel model) {

                //handle item click events here
                Toast.makeText(getActivity(), "Hey " + model.getTitle(), Toast.LENGTH_SHORT).show();


            }
        });


    }

}
